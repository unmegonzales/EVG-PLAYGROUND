const form = document.querySelector("#submissionForm");
const fileInput = document.querySelector("#fileInput");
const browseButton = document.querySelector("#browseButton");
const dropZone = document.querySelector("#dropZone");
const fileList = document.querySelector("#fileList");
const fileTemplate = document.querySelector("#fileTemplate");
const completionBar = document.querySelector("#completionBar");
const completionValue = document.querySelector("#completionValue");
const receipt = document.querySelector("#receipt");
const historyList = document.querySelector("#historyList");
const clearHistory = document.querySelector("#clearHistory");

const acceptedExtensions = new Set(["pdf", "ppt", "pptx", "doc", "docx", "xls", "xlsx", "png", "jpg", "jpeg", "zip"]);
const maxFileSize = 25 * 1024 * 1024;
let selectedFiles = [];

function formatBytes(bytes) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function getHistory() {
  return JSON.parse(localStorage.getItem("visitorSubmissionReceipts") || "[]");
}

function saveHistory(items) {
  localStorage.setItem("visitorSubmissionReceipts", JSON.stringify(items.slice(0, 5)));
}

function renderHistory() {
  const items = getHistory();
  historyList.innerHTML = "";

  if (!items.length) {
    historyList.innerHTML = '<div class="history-card"><strong>No receipts yet</strong><span>Submitted packets will appear here on this device.</span></div>';
    return;
  }

  for (const item of items) {
    const card = document.createElement("div");
    card.className = "history-card";
    card.innerHTML = `<strong>${item.id}</strong><span>${item.name} · ${item.fileCount} file${item.fileCount === 1 ? "" : "s"} · ${item.date}</span>`;
    historyList.append(card);
  }
}

function renderFiles() {
  fileList.innerHTML = "";

  selectedFiles.forEach((file, index) => {
    const node = fileTemplate.content.firstElementChild.cloneNode(true);
    node.querySelector("strong").textContent = file.name;
    node.querySelector("span").textContent = `${formatBytes(file.size)} · ${file.type || "File"}`;
    node.querySelector("button").addEventListener("click", () => {
      selectedFiles.splice(index, 1);
      renderFiles();
      updateCompletion();
    });
    fileList.append(node);
  });
}

function addFiles(fileCollection) {
  const incoming = Array.from(fileCollection).filter((file) => {
    const extension = file.name.split(".").pop().toLowerCase();
    return acceptedExtensions.has(extension) && file.size <= maxFileSize;
  });

  const known = new Set(selectedFiles.map((file) => `${file.name}-${file.size}`));
  for (const file of incoming) {
    const key = `${file.name}-${file.size}`;
    if (!known.has(key)) selectedFiles.push(file);
  }

  renderFiles();
  updateCompletion();
}

function updateCompletion() {
  const data = new FormData(form);
  const fields = ["name", "organization", "email", "team", "category"];
  const completedFields = fields.filter((field) => String(data.get(field) || "").trim()).length;
  const hasConsent = data.get("consent") === "on" ? 1 : 0;
  const hasFiles = selectedFiles.length ? 1 : 0;
  const percent = Math.round(((completedFields + hasConsent + hasFiles) / 7) * 100);

  completionBar.style.width = `${percent}%`;
  completionValue.textContent = `${percent}%`;
}

function validateForm() {
  const controls = Array.from(form.querySelectorAll("input[required], select[required], textarea[required]"));
  let valid = true;

  controls.forEach((control) => {
    const isValid = control.type === "checkbox" ? control.checked : control.checkValidity();
    control.classList.toggle("error", !isValid);
    if (!isValid) valid = false;
  });

  dropZone.classList.toggle("error", selectedFiles.length === 0);
  return valid && selectedFiles.length > 0;
}

function createReceipt() {
  const data = new FormData(form);
  const id = `VFS-${new Date().getFullYear()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
  const visitorName = data.get("name");
  const team = data.get("team");
  const category = data.get("category");
  const date = new Date().toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });

  receipt.classList.add("is-complete");
  receipt.innerHTML = `
    <span class="receipt__number">✓</span>
    <h2>Packet received</h2>
    <p><strong>${id}</strong><br>${selectedFiles.length} file${selectedFiles.length === 1 ? "" : "s"} routed to ${team}. Category: ${category}.</p>
  `;

  const history = getHistory();
  history.unshift({ id, name: visitorName, fileCount: selectedFiles.length, date });
  saveHistory(history);
  renderHistory();
}

browseButton.addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", (event) => addFiles(event.target.files));

["dragenter", "dragover"].forEach((eventName) => {
  dropZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    dropZone.classList.add("is-dragging");
  });
});

["dragleave", "drop"].forEach((eventName) => {
  dropZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    dropZone.classList.remove("is-dragging");
  });
});

dropZone.addEventListener("drop", (event) => addFiles(event.dataTransfer.files));

form.addEventListener("input", updateCompletion);
form.addEventListener("change", updateCompletion);

form.addEventListener("submit", (event) => {
  event.preventDefault();
  if (!validateForm()) {
    receipt.classList.remove("is-complete");
    receipt.innerHTML = '<span class="receipt__number">03</span><h2>Missing details</h2><p>Please complete the required visitor fields, approve the packet, and attach at least one accepted file.</p>';
    return;
  }
  createReceipt();
  form.reset();
  selectedFiles = [];
  renderFiles();
  updateCompletion();
});

form.addEventListener("reset", () => {
  selectedFiles = [];
  setTimeout(() => {
    renderFiles();
    updateCompletion();
    form.querySelectorAll(".error").forEach((control) => control.classList.remove("error"));
    dropZone.classList.remove("error");
  });
});

clearHistory.addEventListener("click", () => {
  saveHistory([]);
  renderHistory();
});

renderHistory();
updateCompletion();
